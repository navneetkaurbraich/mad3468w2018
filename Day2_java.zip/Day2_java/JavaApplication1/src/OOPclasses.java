/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import java.util.Scanner;
/**
 *
 * @author macstudent
 */
public class OOPclasses {
    public static void main(String[] args) {
        
            Bank mybank = new Bank();
            Bank yourbank = new Bank();
            
            System.out.println("Bank ID: "+mybank.bankID);
             System.out.println("Bank Name: "+mybank.bankname);
        
             mybank.getBankName();
             
             yourbank.setBankName("ICICI");
             yourbank.getBankName();
             
             Scanner myInput = new Scanner(System.in);
             String name;
             
             System.out.println("Enter bank Name: ");
             name = myInput.nextLine();
             
             yourbank.setBankName(name);
             yourbank.getBankName();
             
             //create object of arithmetic class
             Arithmetic operation1 = new Arithmetic();
             
             System.out.println("Output of integer addition : " +operation1.addition(10,20));
             
             System.out.println("Output of integer addition : " +operation1.addition(10,20,30));
             
              System.out.println("Output of float addition : " +operation1.addition(10.23f,20.23f));
        
              System.out.println("Output of multiplication : " +operation1.multiplication(10,20,30));
              
              Arithmetic.multiplication(10,20);
//              Arithmetic.addition(10,20);

               Arithmetic.n1 = 20;
              // Arithmetic.n2 = 20;
               System.out.println(Arithmetic.n1 + " " +Arithmetic.n2);
              
    }
    
}
