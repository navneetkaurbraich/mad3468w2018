/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package day3_classactivity;
import java.util.Scanner;

/**
 *
 * @author macstudent
 */
public class Day3_classactivity {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Person p = new Person();
        p.readData();
        p.displayData();
        
        Employee e = new Employee();
        e.readValues();
        e.displayValues();
        
        Faculty f = new Faculty();
        f.setData();
        
    }
    
}

interface Persondata {
    String  name = "Navneet";
     int age = 25;
     void readData();
     void displayData();
}

class Person implements Persondata {
    @Override
    public void  readData(){
        System.out.println("Name of a person = " +name);
    }
    @Override
    public void displayData(){
       System.out.println("Age of a person = " +age); 
    }  
}

interface Employeedata{
    String type= "Part time";
    int Salary = 2000;
    void readValues();
    void displayValues();
}

class Employee extends Person implements Employeedata {
   @Override
    public void  readValues(){
        System.out.println("Job of an Employee = " +type);
    }
    @Override
    public void  displayValues(){
        System.out.println("Salary of an Employee = " +Salary);
    }   
}

interface facultydata{
    String Course="Java Core";
    void setData();
    
}

class Faculty extends Employee implements facultydata{
    @Override
    public void  setData(){
        System.out.println("Course of a faculty = " +Course);
    }
    
}
