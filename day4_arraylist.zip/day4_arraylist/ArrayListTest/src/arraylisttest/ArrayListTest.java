/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package arraylisttest;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;

/**
 *
 * @author macstudent
 */
public class ArrayListTest {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
//        Books book1 = new Books(1,"The Sky",8);
//        Books book2 = new Books(2,"Necklace",3);
//        Books book3 = new Books(3,"Milk",2);
//        Books book4 = new Books(4,"Journey",3);
//        Books book5 = new Books(1,"Wonderer",4);
//        
//        ArrayList<Books> library = new ArrayList<Books>();
//        library.add(book1);
//        library.add(book2);
//        library.add(book3);
//        library.add(book4);
//        library.add(book5);
//        
//        System.out.println("No. of books: " +library.size());
//        
//        for(Books bk: library) {
//            //bk.displayInfo();
//        }
//        
//        library.add(2,new Books(10,"Pacific",9));
//        
//       
//        
//        Collections.sort(library,new bookTitleComparator());
//        library.forEach((bk)->{
//            bk.displayInfo();
//        });
//        
//        Collections.sort(library,new bookRatingComparator());
//        library.forEach((bk)->{
//            bk.displayInfo();
//        });
         
        
        Student stu1 = new Student(1,"Navneet",80);
        Student stu2 = new Student(2,"Arash",75);
        Student stu3 = new Student(3,"Jaspi",85);
        Student stu4 = new Student(4,"Daman",89);
        Student stu5 = new Student(5,"Sanu",75);
        
        ArrayList<Student> library1 = new ArrayList<Student>();
        library1.add(stu1);
        library1.add(stu2);
        library1.add(stu3);
        library1.add(stu4);
        library1.add(stu5);
        
        System.out.println("No. of Students: " +library1.size());
        
        for(Student sk: library1) {
            //bk.displayInfo();
        }
        
        library1.add(2,new Student(8,"Harki",90));
        
        library1.forEach( sk-> {
            sk.displayStudentInfo();
        });
        
         Collections.sort(library1,new percentageComparator());
       library1.forEach((bk)->{
          bk.displayStudentInfo();
       });
        
       
    }
    
}
