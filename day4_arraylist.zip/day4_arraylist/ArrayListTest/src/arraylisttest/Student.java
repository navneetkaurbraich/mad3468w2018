/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package arraylisttest;

import java.util.Comparator;

/**
 *
 * @author macstudent
 */
public class Student {
    int studentID;
    String studentName;
    int percentage;
    
    Student(){
        this.studentID =0;
        this.studentName ="Unknown";
        this.percentage = 0;
    }
    
    Student(int studentID, String studentName, int percentage) {
        this.studentID = studentID;
        this.studentName =studentName;
        this.percentage = percentage;
    }
    
    void setstudentID(int ID) {
        this.studentID = ID;
    }
    
    int getstudentID(){
        return this.studentID;
    }
    
    void setstudentName(String name){
        this.studentName = name;
    }
    
    String getstudentName(){
        return this.studentName;
    }
    
     void setpercentage(int per) {
        this.percentage = per;
    }
    
    int getpercentage(){
        return this.percentage;
    }
    
    void displayStudentInfo(){
        System.out.println("StudentID: " +this.studentID+  "\n Student Name: " +this.studentName+ "\n Percentage: " +this.percentage);
    }
    
}

class percentageComparator implements Comparator<Student>{

 @Override 
    public int compare(Student o1, Student o2) {
      if (o1.percentage == o2.percentage)
          return 0;
      else if (o1.percentage < o2.percentage)
          return 1;
      else
          return -1;
    }
        
    }
