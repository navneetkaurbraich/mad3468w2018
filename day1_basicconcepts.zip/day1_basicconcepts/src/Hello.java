import java.util.Arrays;
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author 728699
 */
public class Hello {
  public static void main(String[] args){
      /*int number = 10; //variable declaration
      float percentage;
      char vowel = 'a';
      String firstName = "Navneet";
      
      System.out.println("Value of number : " +number); //system is class available in java that gives different functionalities to perform on system
      //out genrate output related to console
      //ln for new line
      percentage = 78.6f; //f indictaes the float value
      System.out.println("Value of percentage : " +percentage);
      System.out.println("Vowel = " +vowel);
      System.out.println("First Name = " +firstName);
      
      percentage =10;
      //number = 10.33;
      
      
      vowel = 74;
      number ='j';
    
      System.out.println("Vowel = " +vowel);
      System.out.println("First Name = " +firstName);
      
      System.out.println(1+2+ "test");
      
      number =20;
      if(number > 10) {
          System.out.println("more than 10");
      }
      else if (number ==10) {
          System.out.println("equal to 10");
      }
      
      switch(10+20) {
          case 10:
              System.out.println("Value = 10");
              break;
          case 20:
              System.out.println("value = 20");
              break;
          case 30:
              System.out.println("value = 30");
              break;
          default:
              System.out.println("No matching value");
              break;
      }
      
      vowel = 'a';
      switch(vowel) {
          case ('a' | 'i' | 'o' | 'u' | 'e'):
          //case 'i':
          //case 'e':
          //case 'o':
          //case 'u':
              
              System.out.println("Vowel");
              break;
          default:
              System.out.println("Not a vowel");
              break;
      }
      String province ="Alberta";
      switch(province) {
          case "Ontario" :
              System.out.println("ON");
              break;
              case "Prince Edward" :
              System.out.println("PE");
              break;
              case "Alberta" :
              System.out.println("AB");
              break;
              default:
              System.out.println("Unavailable");
              break;
      }
      
      int numbers[] = new int [5];
      int i;
      for( i=0;i<numbers.length;i++){
          numbers[i] = (int)(Math.random()*100);
          System.out.println("numbers ["+i+ "] ="+numbers[i]);
      }
      
     double PI_VALUE = Math.PI;
     double power =Math.pow(2,2);
      Math.sqrt(144);
      Math.abs(PI_VALUE);
      
      float grades[][] = new float [3] [4];
      
      for(i=0;i<3;i++){
          for(int j=0;j<4;j++) {
      grades[i][j] =10.0f;
  }
  }
      
      int randomNo;
      for(i=0;i<10;i++) {
          randomNo = (int)(Math.random()*10);
          System.out.println("no" +(i+1)+ "=" +randomNo);
      }
      int randomNo1 [] = new int [10];
        for( i=0;i<10;i++) {
          randomNo1[i] = (int)(Math.random()*10);
          System.out.println("no" +(i+1)+ "=" +randomNo1[i]);   
        }
        Arrays.sort(randomNo1);
        for( i=0;i<10;i++) {
          System.out.println("no" +(i+1)+ "=" +randomNo1[i]);   
        }*/
 int n = 5;
    for(int i=1;i<=n;i++)
    {
      for(int j=1;j<=n;j++)
      {
      if((j==1 || j==n) || (i==1 || i==n))
      {
         System.out.print(" *");//1 space
      }else
      {
          System.out.print("  ");//2 spaces
      }
      }
      System.out.println();
    }


  }
}
