/*
 * Author: Jigisha Patel
 * Purpose: Academic
 * 
 */
package multithreading;

/**
 *
 * @author jkp
 */
public class MyMessage extends Thread{
    public void run(){
        System.out.println("Messaging...");
    }
}


