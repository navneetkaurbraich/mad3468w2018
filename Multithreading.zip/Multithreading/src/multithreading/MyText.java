/*
 * Author: Jigisha Patel
 * Purpose: Academic
 * 
 */
package multithreading;

/**
 *
 * @author jkp
 */
public class MyText implements Runnable{

    @Override
    public void run() {
        System.out.println("Texting..");
    }
    
}
